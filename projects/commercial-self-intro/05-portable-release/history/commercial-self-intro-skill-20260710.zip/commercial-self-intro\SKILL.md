---
name: commercial-self-intro
description: Generate commercial-grade self-introductions and personal-brand display packages from a short background plus intended use. Use when the user asks for 自我介绍, 商务介绍, 个人介绍, 个人品牌, IP定位, 抖音/视频号/小红书/公众号/LinkedIn简介, 私域欢迎语, 商务社交或 elevator pitch, 嘉宾/讲师/主持人介绍, 个人名片/长图/PPT展示, or wants one background adapted across channels. Do not use for a full resume or biography unless an introduction package is also requested.
---

# Commercial Self Intro

Turn sparse personal information into a credible, scenario-specific commercial introduction that helps the audience understand the value, believe the proof, and take the next step.

## Read The Right References

1. Read `references/commercial-intro-framework.md` for the core LOOP model, the book-derived method, and the user's commercial operating style.
2. Read `references/scenario-playbooks.md` for the requested channel or occasion only.
3. Read `references/output-contract.md` before producing the final package.
4. Read `references/source-record.md` when the user asks for methodology, citations, current platform guidance, or source provenance. For unstable platform limits, policies, or any request using `最新`/`current`, recheck official sources before answering.
5. Run `scripts/search_self_intro_book.py` when exact PDF grounding, page evidence, or a new book-derived rule is needed. Do not load or reproduce the whole book.

## Minimum Input

Accept as little as:

- `简介`: any short, messy description of the person, experience, business, strengths, or results.
- `用途`: the platform, occasion, audience, or desired use.

Treat these as optional accelerators, not blockers:

- target audience
- desired audience action
- verified numbers, cases, credentials, clients, media, awards, or products
- preferred tone
- prohibited claims or privacy boundaries

If information is thin, infer conservatively, state the assumptions, and produce a useful first version. Ask at most one question only when the target audience or desired action cannot be inferred and different answers would materially change the introduction.

## Workflow

### 1. Build A Truth Ledger

Extract every usable fact and classify it:

- `A - verified`: evidence, source, link, certificate, public record, or user-confirmed fact exists.
- `B - user-stated`: supplied by the user but not independently verified.
- `C - aspiration`: desired positioning, unverified superlative, or result claim that still needs proof.

Use A directly. Use B with precise, non-inflated wording. Do not present C as fact; convert it into a goal, a cautious formulation, or a `待核实` item.

### 2. Run The LOOP Engine

- `L - Listener`: identify the audience, scene, attention state, pain point, and ideal reaction.
- `O - Outcome`: state the future or business result the audience can obtain because this person participates.
- `O - Ownable Proof`: select the smallest, strongest, most relevant proof. Prefer a specific result, case, mechanism, credential, or uncommon experience over a title pile.
- `P - Prompt Next Step`: give one natural next action that fits the relationship and platform.

Keep the book's three-sentence spine for short versions: `future -> proof -> action`.

### 3. Choose One Commercial Position

Write a one-sentence positioning judgment before drafting. It must answer:

`For which people, in which situation, what result does this person help create, and why should anyone believe it?`

Do not stack every identity. Keep one primary identity, up to two supporting identities, and only evidence relevant to the current use.

### 4. Generate Scenario Assets

Use the selected playbook. Default to one recommended version plus two meaningfully different alternatives. Adapt structure, length, vocabulary, proof density, and CTA to the platform; do not merely shorten one master paragraph.

For any version labeled 15, 18, 30, or 60 seconds, run `scripts/check_intro_length.py --target <seconds> "<copy>"`. Revise until the estimate is within the reported target band. Treat the result as a pacing estimate and still recommend a real recording for final delivery.

When the user asks for a visual deliverable such as a long image, profile card, one-page PPT, or poster, create the actual artifact with an available design/presentation tool when possible. Also provide the content hierarchy and replaceable evidence fields. Do not stop at a vague design suggestion.

### 5. Apply Commercial And Compliance Checks

- Lead with audience value, not a resume dump.
- Prefer concrete outcomes: save time, reduce errors, increase revenue, retain experience, lower risk, gain confidence, or reach a defined life/career result.
- Never invent client names, titles, partnerships, numbers, awards, media appearances, or outcomes.
- Treat large-brand logos and institutional titles as evidence only when the relationship and wording are supportable. Add a scope note when cooperation depth varies.
- Avoid absolute claims such as `国家级`, `最高级`, `最佳`, `第一`, `唯一`, or `顶级` unless the user provides current, applicable proof and explicitly accepts the compliance risk.
- When citing data, rankings, studies, or conversion results, require a source, scope, and date.
- Protect private information. Do not expose phone numbers, addresses, client-confidential facts, or sensitive personal history without explicit need.

### 6. Score, Rewrite, Then Deliver

Score the draft with the rubric in `references/output-contract.md`. Rewrite up to three times until the score reaches 85/100 or further improvement requires missing evidence. If evidence is the blocker, deliver the strongest honest version and list the three highest-value proof items to collect.

## Voice

- Write in Chinese unless the user asks otherwise.
- Give the positioning judgment first.
- Use direct, clean, speakable business language.
- Make memorable lines short enough to say aloud.
- Avoid jargon, empty motivation, inflated adjectives, and robotic template language.
- Keep confidence and humility in balance: credible, not timid; persuasive, not boastful.

## Final Rule

A commercial self-introduction is successful only when the intended audience can answer three questions after hearing it: `What can this person help me achieve? Why should I believe them? What should I do next?`
