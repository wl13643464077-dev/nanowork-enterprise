#!/usr/bin/env python3
"""Search the local Chinese PDF and return page-cited snippets."""

from __future__ import annotations

import argparse
import re
import sys
import unicodedata
from pathlib import Path

from pypdf import PdfReader


DEFAULT_PDF = Path(r"I:\自我介绍的技术（【日】横川裕之，台海出版社，2023年02月）.pdf")
KNOWN_SIZE = 7_313_540


def normalize(text: str) -> str:
    return unicodedata.normalize("NFKC", text).replace("\x00", "")


def find_default_pdf() -> Path:
    if DEFAULT_PDF.exists():
        return DEFAULT_PDF
    for candidate in Path("I:/").glob("*.pdf"):
        try:
            if candidate.stat().st_size == KNOWN_SIZE:
                return candidate
        except OSError:
            continue
    raise FileNotFoundError(
        "未找到《自我介绍的技术》PDF。请用 --pdf 指定文件路径。"
    )


def parse_pages(spec: str | None, total: int) -> set[int] | None:
    if not spec:
        return None
    pages: set[int] = set()
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            start_text, end_text = part.split("-", 1)
            start, end = int(start_text), int(end_text)
            if start > end:
                start, end = end, start
            pages.update(range(max(1, start), min(total, end) + 1))
        else:
            page = int(part)
            if 1 <= page <= total:
                pages.add(page)
    return pages


def make_snippet(text: str, positions: list[int], context: int) -> str:
    start = max(0, min(positions) - context)
    end = min(len(text), max(positions) + context)
    return re.sub(r"\s+", " ", text[start:end]).strip()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="检索《自我介绍的技术》并输出PDF页码与短摘录。"
    )
    parser.add_argument("query", help="检索词。空格分隔多个词。")
    parser.add_argument("--pdf", type=Path, help="覆盖默认PDF路径。")
    parser.add_argument("--limit", type=int, default=8, help="最多返回多少页。")
    parser.add_argument("--context", type=int, default=140, help="命中前后字符数。")
    parser.add_argument("--pages", help="页码范围，例如 59-83,90,111-128。")
    parser.add_argument(
        "--mode", choices=("any", "all"), default="any", help="多词匹配方式。"
    )
    parser.add_argument(
        "--phrase", action="store_true", help="把整个query作为一个完整短语。"
    )
    args = parser.parse_args()

    pdf_path = args.pdf or find_default_pdf()
    if not pdf_path.exists():
        print(f"PDF不存在: {pdf_path}", file=sys.stderr)
        return 2

    reader = PdfReader(str(pdf_path))
    allowed = parse_pages(args.pages, len(reader.pages))
    raw_terms = [args.query] if args.phrase else args.query.split()
    terms = [normalize(term).casefold() for term in raw_terms if term.strip()]
    if not terms:
        print("请提供至少一个非空检索词。", file=sys.stderr)
        return 2

    hits: list[tuple[int, str]] = []
    for index, page in enumerate(reader.pages, start=1):
        if allowed is not None and index not in allowed:
            continue
        text = normalize(page.extract_text() or "")
        folded = text.casefold()
        positions = [folded.find(term) for term in terms]
        matched = all(pos >= 0 for pos in positions) if args.mode == "all" else any(
            pos >= 0 for pos in positions
        )
        if not matched:
            continue
        present_positions = [pos for pos in positions if pos >= 0]
        hits.append((index, make_snippet(text, present_positions, args.context)))
        if len(hits) >= max(1, args.limit):
            break

    print(f"PDF: {pdf_path}")
    print(f"查询: {' | '.join(raw_terms)}")
    print(f"命中页数: {len(hits)}")
    for page_number, snippet in hits:
        print(f"\nPDF p.{page_number}\n{snippet}")
    return 0 if hits else 1


if __name__ == "__main__":
    raise SystemExit(main())
